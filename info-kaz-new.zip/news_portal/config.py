ADMIN_URL_PREFIX = 'aadminkaa01news'
